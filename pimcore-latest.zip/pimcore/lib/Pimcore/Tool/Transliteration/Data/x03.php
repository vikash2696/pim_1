<?php

$base = [
  0x00 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x10 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x20 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x30 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x40 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', null,
  0x50 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0x60 => '', '', '', null, null, null, null, null, null, null, null, null, null, null, null, null,
  0x70 => null, null, null, null, '\'', ',', null, null, null, null, '', null, null, null, '?', null,
  0x80 => null, null, null, null, '', '', 'A', ';', 'E', 'I', 'I', null, 'O', null, 'U', 'O',
  0x90 => 'I', 'A', 'B', 'G', 'D', 'E', 'Z', 'I', 'Th', 'I', 'K', 'L', 'M', 'N', 'X', 'O',
  0xA0 => 'P', 'R', null, 'S', 'T', 'Y', 'F', 'H', 'Ps', 'O', 'I', 'Y', 'a', 'e', 'i', 'i',
  0xB0 => 'y', 'a', 'b', 'g', 'd', 'e', 'z', 'i', 'th', 'i', 'k', 'l', 'm', 'n', 'x', 'o',
  0xC0 => 'p', 'r', 's', 's', 't', 'y', 'f', 'h', 'ps', 'o', 'i', 'y', 'o', 'y', 'o', null,
  0xD0 => 'b', 'th', 'U', 'U', 'U', 'ph', 'p', '&', null, null, 'St', 'st', 'W', 'w', 'Q', 'q',
  0xE0 => 'Sp', 'sp', 'Sh', 'sh', 'F', 'f', 'Kh', 'kh', 'H', 'h', 'G', 'g', 'CH', 'ch', 'Ti', 'ti',
  0xF0 => 'k', 'r', 'c', 'j', null, null, null, null, null, null, null, null, null, null, null, null,
];
