<?php

$base = [
  0x00 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0x10 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0x20 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0x30 => null, 'A', 'B', 'G', 'D', 'E', 'Z', 'E', 'E', 'T`', 'Zh', 'I', 'L', 'Kh', 'Ts', 'K',
  0x40 => 'H', 'Dz', 'Gh', 'Ch', 'M', 'Y', 'N', 'Sh', 'O', 'Ch`', 'P', 'J', 'Rh', 'S', 'V', 'T',
  0x50 => 'R', 'Ts`', 'W', 'P`', 'K`', 'O', 'F', null, null, '<', '\'', '/', '!', ',', '?', '.',
  0x60 => null, 'a', 'b', 'g', 'd', 'e', 'z', 'e', 'e', 't`', 'zh', 'i', 'l', 'kh', 'ts', 'k',
  0x70 => 'h', 'dz', 'gh', 'ch', 'm', 'y', 'n', 'sh', 'o', 'ch`', 'p', 'j', 'rh', 's', 'v', 't',
  0x80 => 'r', 'ts`', 'w', 'p`', 'k`', 'o', 'f', 'ew', null, '.', '-', null, null, null, null, null,
  0x90 => null, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0xA0 => '', '', null, '', '', '', '', '', '', '', '', '', '', '', '', '',
  0xB0 => '@', 'e', 'a', 'o', 'i', 'e', 'e', 'a', 'a', 'o', null, 'u', '\'', '', '', '',
  0xC0 => '', '', '', ':', '', null, null, null, null, null, null, null, null, null, null, null,
  0xD0 => '', 'b', 'g', 'd', 'h', 'v', 'z', 'kh', 't', 'y', 'k', 'k', 'l', 'm', 'm', 'n',
  0xE0 => 'n', 's', '`', 'p', 'p', 'ts', 'ts', 'q', 'r', 'sh', 't', null, null, null, null, null,
  0xF0 => 'V', 'oy', 'i', '\'', '"', null, null, null, null, null, null, null, null, null, null, null,
];
