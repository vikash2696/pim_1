<?php

$base = [
  0x00 => null, 'N', 'N', 'H', null, 'a', 'aa', 'i', 'ii', 'u', 'uu', 'R', 'L', 'eN', 'e', 'e',
  0x10 => 'ai', 'oN', 'o', 'o', 'au', 'k', 'kh', 'g', 'gh', 'ng', 'c', 'ch', 'j', 'jh', 'ny', 'tt',
  0x20 => 'tth', 'dd', 'ddh', 'nn', 't', 'th', 'd', 'dh', 'n', 'nnn', 'p', 'ph', 'b', 'bh', 'm', 'y',
  0x30 => 'r', 'rr', 'l', 'l', 'lll', 'v', 'sh', 'ss', 's', 'h', null, null, '\'', '\'', 'aa', 'i',
  0x40 => 'ii', 'u', 'uu', 'R', 'RR', 'eN', 'e', 'e', 'ai', 'oN', 'o', 'o', 'au', '', null, null,
  0x50 => 'AUM', '\'', '\'', '`', '\'', null, null, null, 'q', 'khh', 'ghh', 'z', 'dddh', 'rh', 'f', 'yy',
  0x60 => 'RR', 'LL', 'L', 'LL', ' / ', ' // ', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
  0x70 => '.', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0x80 => null, 'N', 'N', 'H', null, 'a', 'aa', 'i', 'ii', 'u', 'uu', 'R', 'RR', null, null, 'e',
  0x90 => 'ai', null, null, 'o', 'au', 'k', 'kh', 'g', 'gh', 'ng', 'c', 'ch', 'j', 'jh', 'ny', 'tt',
  0xA0 => 'tth', 'dd', 'ddh', 'nn', 't', 'th', 'd', 'dh', 'n', null, 'p', 'ph', 'b', 'bh', 'm', 'y',
  0xB0 => 'r', null, 'l', null, null, null, 'sh', 'ss', 's', 'h', null, null, '\'', null, 'aa', 'i',
  0xC0 => 'ii', 'u', 'uu', 'R', 'RR', null, null, 'e', 'ai', null, null, 'o', 'au', '', null, null,
  0xD0 => null, null, null, null, null, null, null, '+', null, null, null, null, 'rr', 'rh', null, 'yy',
  0xE0 => 'RR', 'LL', 'L', 'LL', null, null, '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
  0xF0 => 'r\'', 'r`', 'Rs', 'Rs', '1/', '2/', '3/', '4/', ' 1 - 1/', '/16', '', null, null, null, null, null,
];
