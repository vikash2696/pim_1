<?php

$base = [
  0x00 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0x10 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0x20 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0x30 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0x40 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0x50 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0x60 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0x70 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0x80 => 'k', 'kh', 'g', 'gh', 'ng', 'c', 'ch', 'j', 'jh', 'ny', 't', 'tth', 'd', 'ddh', 'nn', 't',
  0x90 => 'th', 'd', 'dh', 'n', 'p', 'ph', 'b', 'bh', 'm', 'y', 'r', 'l', 'v', 'sh', 'ss', 's',
  0xA0 => 'h', 'l', 'q', 'a', 'aa', 'i', 'ii', 'u', 'uk', 'uu', 'uuv', 'ry', 'ryy', 'ly', 'lyy', 'e',
  0xB0 => 'ai', 'oo', 'oo', 'au', 'a', 'aa', 'aa', 'i', 'ii', 'y', 'yy', 'u', 'uu', 'ua', 'oe', 'ya',
  0xC0 => 'ie', 'e', 'ae', 'ai', 'oo', 'au', 'M', 'H', 'a`', '', '', '', 'r', '', '!', '',
  0xD0 => '', '', '', '', '.', ' // ', ':', '+', '++', ' * ', ' /// ', 'KR', '\'', null, null, null,
  0xE0 => '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', null, null, null, null, null, null,
  0xF0 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
];
