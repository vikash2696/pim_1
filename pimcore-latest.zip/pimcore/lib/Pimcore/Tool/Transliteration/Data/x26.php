<?php

$base = [
  0x00 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x10 => '', '', '', '', null, null, null, null, null, '', '', '', '', '', '', '',
  0x20 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x30 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x40 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x50 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x60 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x70 => '', '', null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0x80 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0x90 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0xA0 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0xB0 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0xC0 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0xD0 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0xE0 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0xF0 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
];
