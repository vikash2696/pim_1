pimcore.available_languages = <?= \Zend_Json::encode($this->languages) ?>;
